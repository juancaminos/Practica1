package com.practica.Libros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
