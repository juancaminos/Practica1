package com.practica.Libros.model;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;

import javax.annotation.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "titulo",
        "autor",
        "editorial",
        "link",
        "imagen"
})
@Generated("jsonschema2pojo")
public class Libro {

    @JsonProperty("titulo")
    private String titulo;
    @JsonProperty("autor")
    private String autor;
    @JsonProperty("editorial")
    private String editorial;
    @JsonProperty("link")
    private String link;
    @JsonProperty("imagen")
    private String imagen;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("titulo")
    public String getTitulo() {
        return titulo;
    }

    @JsonProperty("titulo")
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @JsonProperty("autor")
    public String getAutor() {
        return autor;
    }

    @JsonProperty("autor")
    public void setAutor(String autor) {
        this.autor = autor;
    }

    @JsonProperty("editorial")
    public String getEditorial() { return editorial; }

    @JsonProperty("editorial")
    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    @JsonProperty("link")
    public String getLink() {
        return link;
    }

    @JsonProperty("link")
    public void setLink(String link) {
        this.link = link;
    }

    @JsonProperty("imagen")
    public String getImagen() {
        return imagen;
    }

    @JsonProperty("imagen")
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
