package com.practica.Libros.service;

import com.practica.Libros.model.LibrosServiceModel;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LibrosService {

    private String url = "https://www.googleapis.com/books/v1/volumes?q=";

    public LibrosServiceModel getLibros(String busqueda){
        final RestTemplate template = new RestTemplate();
        final String urlfinal = url+busqueda;
        final HttpMethod method = HttpMethod.GET;
        final ResponseEntity<LibrosServiceModel> response = template.exchange(urlfinal, method, null, LibrosServiceModel.class);
        return response.getBody();
    }
}
