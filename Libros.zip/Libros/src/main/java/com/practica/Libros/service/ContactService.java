package com.practica.Libros.service;

import com.practica.Libros.model.Contact;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactService {

    public List<Contact> getContacts(){
        return List.of(new Contact("Juan","674523468","juan@gmail.com"),
                        new Contact("Alberto","698023123","alberto@gmail.com"),
                        new Contact("Mario","634675773","marioo@gmail.com"));
    }
}
