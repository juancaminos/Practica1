package com.practica.Libros.controller;

import com.practica.Libros.model.Contact;
import com.practica.Libros.model.LibrosServiceModel;
import com.practica.Libros.model.User;
import com.practica.Libros.service.ContactService;
import com.practica.Libros.service.LibrosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class RestControllerApp {

    private String correo_valido = "hola@gmail.com";
    private String contraseña_valida = "1234";

    @Autowired
    private LibrosService librosapi;

    @Autowired
    private ContactService contactos;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody @Valid User user) {
        if(user.getUsername().equals(correo_valido) && user.getPassword().equals(contraseña_valida)){
            return new ResponseEntity<>("Login Correcto.", HttpStatus.OK);
        }
        return new ResponseEntity<>("El correo o la contraseña son incorrectos.", HttpStatus.NOT_ACCEPTABLE);
    }

    @GetMapping("/buscar")
    public ResponseEntity<LibrosServiceModel> buscar(@RequestParam("busqueda") String busqueda) {
        LibrosServiceModel model = new LibrosServiceModel();
        model = librosapi.getLibros(busqueda);
        return new ResponseEntity<>(model,HttpStatus.OK);
    }

    @PostMapping("/contact")
    public ResponseEntity<String> createUser(@RequestBody @Valid Contact contact){
        List<Contact> contacts =contactos.getContacts();
        for(Contact contacto:contacts){
            if(contact.equals(contacto)){
                return new ResponseEntity<>( contact.getName() + " esta en la lista de contactos", HttpStatus.OK);
            }
        }
        return new ResponseEntity<>( contact.getName() + " no esta en la lista de contactos", HttpStatus.NOT_ACCEPTABLE);
    }

}
