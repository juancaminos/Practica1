const correo = document.getElementById("correo");
const contrasenia = document.getElementById("contraseña");

function  login(){
  try {
    const data = { username: correo.value, password: contrasenia.value };
    console.log(correo.value);
    console.log(contrasenia.value);
    console.log(JSON.stringify(data));
    const direccion = '/myapplication/api/login';
    fetch(direccion, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
        })
        .then(response => {
          response.json();
          console.log(response);
          if(response.status == 200){
            alert("Login correcto");
            document.location.href="../Libros/index.html";
          } else {
            alert("El correo o la contrasenia son incorrectos.");
          }
        })
  } catch (e) {
    console.error(e.message);
  }
  return false;
 }