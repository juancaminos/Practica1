var outputList = document.getElementById("list-output");

var nombre = document.getElementById("nombre");
var numero = document.getElementById("numero");
var correo = document.getElementById("correo");

function  buscarcontacto(){
 try {
    outputList.innerHTML = null;
   const data = {name: nombre.value, number: numero.value, email: correo.value};
   console.log(nombre.value);
   console.log(numero.value);
   console.log(correo.value);
   console.log(JSON.stringify(data));
   const direccion = '/myapplication/api/contact';
   fetch(direccion, {
       method: 'POST',
       headers: {
           'Content-Type': 'application/json'
       },
       body: JSON.stringify(data)
       })
       .then(response => {
         response.json();
         console.log(response);
         if(response.status == 200){
           alert("El contacto existe");
            displayResults(nombre.value, numero.value, correo.value);
         } else {
           alert("El contacto no existe.");
         }
       })
 } catch (e) {
   console.error(e.message);
 }
 return false;
}

function displayResults(nombre, numero, correo) {
        outputList.innerHTML += '<div class="row mt-4">' +
                                formatOutput(nombre,numero, correo) +
                                '</div>';
        console.log(outputList);
}

function formatOutput(nombre, numero, correo) {
     var htmlCard = `<div class="col-lg-6">
       <div class="card" style="">
         <div class="row no-gutters">
           <div class="col-md-8">
             <div class="card-body">
               <h5 class="card-title">${nombre}</h5>
               <p class="card-text">Numero de telefono: ${numero}</p>
               <p class="card-text">Correo electronico: ${correo}</p>
             </div>
           </div>
         </div>
       </div>
     </div>`
     return htmlCard;
}